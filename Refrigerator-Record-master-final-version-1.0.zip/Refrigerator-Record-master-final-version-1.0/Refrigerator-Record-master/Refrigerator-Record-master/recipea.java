import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class recipea {
    private List<recipe> recipes;
    public recipea() {
        recipes = new ArrayList<>();
        initializeRecipes();
    }
    public void initializeRecipes() {
        recipe a = new recipe("竹筍炒肉",
                Arrays.asList("竹筍","肉","油","鹽"),
                "做法:熱鍋燒油，下肉，下竹筍，炒，加鹽，適合家庭的一小菜，小孩應該挺愛吃");
        recipes.add(a);

        a = new recipe("雞湯",
                Arrays.asList("雞肉","水","鹽"),
                "做法:鍋裡加水，加雞肉，加鹽，蓋蓋子煮一段時間，雞湯來嘍");
        recipes.add(a);

        a = new recipe("麵包",
                Arrays.asList("麵粉", "水", "雞蛋"),
                "做法:麵粉+水+雞蛋攪一攪，麵團拿去烤");
        recipes.add(a);
        a = new recipe("法式長棍麵包(穿甲彈)",
                Arrays.asList("麵粉", "水", "酵母粉"),
                "做法:麵粉+水+酵母粉攪一攪，麵團拿去烤");
        recipes.add(a);
        a = new recipe("麻婆豆腐",
                Arrays.asList("豆腐","豬絞肉","豆瓣醬","蒜末","蔥末","醬油","糖","花椒粉","鹽","水"),
                "將豆腐切塊，豬絞肉炒熟後加入豆瓣醬和蒜末翻炒，加入豆腐和其他調味料煮至入味");
        recipes.add(a);
        a = new recipe("西紅柿炒蛋",
                Arrays.asList("西紅柿","雞蛋","蔥","鹽","油"),
                "雞蛋打散炒熟取出，西紅柿切塊炒至軟爛，加入雞蛋和鹽翻炒均勻。");
        recipes.add(a);
        a = new recipe("宮保雞丁",
                Arrays.asList("雞胸肉","花生乾","辣椒","蔥","蒜","醬油","糖","醋","鹽","油"),
                "雞肉切丁，用醬油、鹽腌制，炒花生至金黃取出，炒雞丁至熟，加入乾辣椒、蔥、蒜翻炒，最後加入醬油、糖、醋調味。");
        recipes.add(a);
        a = new recipe("酸辣湯",
                Arrays.asList("豆腐","木耳","胡蘿蔔","雞蛋","白胡椒粉","醋","鹽","香菜","油"),
                "豆腐、木耳、胡蘿蔔切絲，雞蛋打散，鍋中加水煮沸，加入所有材料煮熟，調味後撒上香菜。");
        recipes.add(a);
        a = new recipe("紅燒排骨",
                Arrays.asList("豬排骨","醬油","糖","蔥","薑","八角","料酒","水"),
                "排骨焯水後炒糖色，加入排骨翻炒均勻，加入其他調料和水燉煮至排骨軟爛。");
        recipes.add(a);
        a = new recipe("魚香茄子",
                Arrays.asList("茄子","肉末","蒜末","醬油","糖","醋","辣豆瓣醬","蔥"),
                "茄子切條炸至金黃，肉末炒熟，加入蒜末和辣豆瓣醬翻炒，加入茄子和其他調料炒匀。");
        recipes.add(a);
        a = new recipe("蝦仁炒蛋",
                Arrays.asList("蝦仁","雞蛋","蔥","鹽","油"),
                "蝦仁焯水，雞蛋打散炒熟，加入蝦仁和鹽翻炒均勻。");
        a = new recipe("辣子雞丁",
                Arrays.asList("雞胸肉","乾辣椒","花椒","蔥","蒜","醬油","糖","醋","鹽","油"),
                "雞肉切丁用醬油、鹽腌制，炒乾辣椒和花椒至香，加入雞丁炒熟，加入其他調料炒匀。");
        recipes.add(a);
        a = new recipe("青椒炒肉絲",
                Arrays.asList("青椒","豬肉絲","蒜","醬油","鹽","油"),
                "豬肉絲用醬油腌制，青椒切絲，蒜切片，肉絲炒熟後加入蒜片和青椒翻炒，加鹽調味。");
        recipes.add(a);
        a = new recipe("白菜豆腐湯",
                Arrays.asList("白菜","豆腐","蔥","薑","鹽","香油"),
                "白菜切段，豆腐切塊，鍋中加水煮沸，加入所有材料煮熟，調味後滴入香油。");
        recipes.add(a);
        a = new recipe("可樂雞翅",
                Arrays.asList("雞翅","可樂","醬油","蔥","薑"),
                "雞翅焯水，鍋中加可樂和醬油煮沸，加入雞翅、蔥、薑煮至入味。");
        recipes.add(a);
        a = new recipe("醋溜土豆絲",
                Arrays.asList("土豆","醋","鹽","糖","蔥","乾辣椒","油"),
                "土豆切絲用清水沖洗，炒乾辣椒和蔥，加入土豆絲翻炒，加醋、鹽、糖調味。");
        recipes.add(a);
        a = new recipe("蒜蓉蒸蝦",
                Arrays.asList("蝦","蒜","鹽","料酒","蔥","油"),
                "蝦剖背去腸線，蒜切末，蝦排盤，蒜末、鹽、料酒拌勻，蒸熟後撒蔥花淋油。");
        recipes.add(a);
        a = new recipe("番茄牛肉麵",
                Arrays.asList("牛肉","番茄","麵條","蔥","蒜","鹽","糖","醬油"),
                "牛肉切塊焯水，番茄切塊，鍋中加水煮沸，加入所有材料煮熟，最後加入麵條煮透。");
        recipes.add(a);
        a = new recipe("蒸魚",
                Arrays.asList("魚","蔥","薑","醬油","鹽","料酒"),
                "魚去鱗洗淨，蔥薑切絲，魚排盤撒鹽和料酒，蒸熟後淋上醬油。");
        recipes.add(a);
        a = new recipe("炸醬麵",
                Arrays.asList("豬絞肉","麵條","黃豆醬","甜麵醬","蔥","蒜","糖","醬油"),
                "豬肉炒熟，加入黃豆醬和甜麵醬翻炒，加入蔥蒜、糖和醬油調味，拌在煮熟的麵條上。");
        recipes.add(a);
        a = new recipe("宮保蝦仁",
                Arrays.asList("蝦仁","花生","乾辣椒","蔥","蒜","醬油","糖","醋","鹽","油"),
                "蝦仁焯水，炒花生至金黃取出，炒乾辣椒和蔥蒜，加入蝦仁和其他調料炒匀。");
        recipes.add(a);
        a = new recipe("蔥爆羊肉",
                Arrays.asList("羊肉片","蔥","蒜","醬油","鹽","糖","油"),
                "羊肉片用醬油、鹽腌制，蔥切段，羊肉炒熟後加入蔥段和蒜片炒匀。");
        recipes.add(a);
        a = new recipe("魚香肉絲",
                Arrays.asList("豬肉絲","木耳","胡蘿蔔","蔥","蒜","醬油","糖","醋","鹽","辣豆瓣醬"),
                "豬肉絲用醬油腌制，木耳泡發，胡蘿蔔切絲，炒肉絲至熟，加入其他材料炒匀。");
        recipes.add(a);
        a = new recipe("糖醋排骨",
                Arrays.asList("豬排骨","醋","糖","醬油","蔥","薑"),
                "排骨焯水後炒糖色，加入排骨翻炒，加入醋、糖、醬油、蔥、薑煮至入味。");
        recipes.add(a);
    }
    public recipe RandomRecipe() {
        if (recipes.isEmpty()) {
            return null; // 或者返回适当的默认值
        }
        Random random = new Random();
        int index = random.nextInt(recipes.size());
        return recipes.get(index);
    }
}
