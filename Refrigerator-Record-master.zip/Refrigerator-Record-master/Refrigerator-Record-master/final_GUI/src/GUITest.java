import javax.swing.JFrame;
public class GUITest {
    public static void main(String[] args) {
        GUI ui = new GUI();
        ui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ui.setSize(720, 1080);
        ui.setVisible(true);

    }

}
